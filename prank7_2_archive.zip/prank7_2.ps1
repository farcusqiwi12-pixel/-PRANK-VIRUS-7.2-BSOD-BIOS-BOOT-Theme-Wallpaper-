Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms

$themePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"

$oldAppsTheme = (Get-ItemProperty $themePath).AppsUseLightTheme
$oldSystemTheme = (Get-ItemProperty $themePath).SystemUsesLightTheme
$oldWallpaper = (Get-ItemProperty "HKCU:\Control Panel\Desktop").WallPaper

function Update-Wallpaper {
    RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
}

Set-ItemProperty $themePath AppsUseLightTheme 1
Set-ItemProperty $themePath SystemUsesLightTheme 1

$newWallpaper = "C:\Windows\Web\Wallpaper\Windows\img0.jpg"
Set-ItemProperty "HKCU:\Control Panel\Desktop" WallPaper $newWallpaper
Update-Wallpaper

[console]::beep(900,300)
[console]::beep(700,300)
[console]::beep(500,300)

[xml]$bsodXaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        WindowStyle="None" WindowState="Maximized" ResizeMode="NoResize"
        Background="#0078D7" Topmost="True">
    <Grid>
        <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center">
            <TextBlock FontSize="80" Foreground="White" TextAlignment="Center">:(</TextBlock>
            <TextBlock FontSize="28" Foreground="White" Margin="0,20,0,0" TextAlignment="Center">
На вашем ПК возникла проблема, и его необходимо перезагрузить.
            </TextBlock>
            <TextBlock Name="BsodText" FontSize="20" Foreground="White" Margin="0,20,0,0" TextAlignment="Center">
Сбор данных об ошибке: 0%
            </TextBlock>
        </StackPanel>
    </Grid>
</Window>
"@

$bsodWindow = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $bsodXaml))
$BsodText = $bsodWindow.FindName("BsodText")

$bsodWindow.Add_Loaded({
    for ($i=0; $i -le 100; $i+=5) {
        $BsodText.Text = "Сбор данных об ошибке: $i%"
        Start-Sleep -Milliseconds 350
    }
    $bsodWindow.Close()
})

$bsodWindow.ShowDialog() | Out-Null

[xml]$biosXaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        WindowStyle="None" WindowState="Maximized" ResizeMode="NoResize"
        Background="Black" Topmost="True">
    <Grid>
        <StackPanel Margin="40">
            <TextBlock FontSize="20" Foreground="Lime">Phoenix BIOS v4.0</TextBlock>
            <TextBlock Name="BiosText" FontSize="18" Foreground="Lime" Margin="0,20,0,0">
Checking RAM...
            </TextBlock>
        </StackPanel>
    </Grid>
</Window>
"@

$biosWindow = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $biosXaml))
$BiosText = $biosWindow.FindName("BiosText")

$biosWindow.Add_Loaded({
    $lines = @("Checking RAM...","Detecting drives...","Loading boot sector...","Booting Windows...")
    foreach ($line in $lines) {
        $BiosText.Text = $line
        Start-Sleep -Seconds 1
    }
    $biosWindow.Close()
})

$biosWindow.ShowDialog() | Out-Null

[xml]$bootXaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        WindowStyle="None" WindowState="Maximized" ResizeMode="NoResize"
        Background="#000000" Topmost="True">
    <Grid>
        <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center">
            <TextBlock FontSize="36" Foreground="White" TextAlignment="Center">
Загрузка Windows
            </TextBlock>
            <TextBlock Name="BootText" FontSize="20" Foreground="White" Margin="0,20,0,0" TextAlignment="Center">
Пожалуйста, подождите...
            </TextBlock>
            <ProgressBar Name="Progress" Width="400" Height="25" Margin="0,30,0,0"/>
        </StackPanel>
    </Grid>
</Window>
"@

$bootWindow = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $bootXaml))
$Progress = $bootWindow.FindName("Progress")
$BootText = $bootWindow.FindName("BootText")

$bootWindow.Add_Loaded({
    for ($i=0; $i -le 100; $i+=2) {
        $Progress.Value = $i
        Start-Sleep -Milliseconds 250
    }

    Set-ItemProperty $themePath AppsUseLightTheme $oldAppsTheme
    Set-ItemProperty $themePath SystemUsesLightTheme $oldSystemTheme
    Set-ItemProperty "HKCU:\Control Panel\Desktop" WallPaper $oldWallpaper
    Update-Wallpaper

    [System.Windows.MessageBox]::Show(
"😂 Ты попался!
Это был розыгрыш.
Тема и обои восстановлены.",
"Prank Virus 7.2",
"OK",
"Information"
    )

    $bootWindow.Close()
})

$bootWindow.ShowDialog() | Out-Null
